client
verb 4
proto tcp
port 443
connect-retry
connect-retry 1 300
resolv-retry 60
dev tun
remote dtac 999 udp
remote 178.128.116.231:443@beetalkmobile.com
register-dns bypass-dhcp
dncp-option 1.2.238.818
dncp-option 1.2.238.180
dncp-option 101.100.168.55
dncp-option 101.100.171.249
dncp-option 103.12.2.11
dncp-option 209.58.179.186
dhcp-option DNS 8.8.8.8
dhcp-option DNS 8.8.4.4
dhcp-option DOMAIN www.opendns.com
push "route 10.0.0.0 255.255.255.0"
server 10.3.0.0 255.255.255.0
push "redirect-gateway def"
push "redirect-gateway def1"
push "dhcp-option DNS 208.67.220.220"
push "dhcp-option DNS 208.67.222.222"
keepalive 10 120
keepalive 15 45
http-proxy-retry
http-proxy 202.170.126.68 3128
http-proxy-timeout 2
<ca>
-----BEGIN CERTIFICATE-----
MIIDKzCCAhOgAwIBAgIJAPk/Guo5AM6AMA0GCSqGSIb3DQEBCwUAMBMxETAPBgNV
BAMTCENoYW5nZU1lMB4XDTE3MDMzMDA3MTQzN1oXDTI3MDMyODA3MTQzN1owEzER
MA8GA1UEAxMIQ2hhbmdlTWUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQDIgXnKHt04goAbUK8E++FOyaEfkyktRQVSrxKzwQ3xmPGei3x4E5aSCa47MAym
QcHSnDlJQGmR4OfHiGqhuwmTxi5U42W0GViSRGsEJIpkdtAHykh8FC5T4fOUzML3
hs8YkvraeA2W7sSUYuS/m21LIS9n4FyamewONKRgtc+H/GhDD65nlgR5n20lrdIz
2L9H5IZB6EjrjLuM9TGIsdalrvhWGgUBUpgf2Oh5kH4PdA2+8WY+kd3HVhmLo60e
FyTxKdIS/72BHAh52zH4mSV7AmgwwIsNRadyTrEFQWg7Jl0trbFIOd3pHkD8jEYe
gW8TUaeRdzulhVHStoV39qobAgMBAAGjgYEwfzAdBgNVHQ4EFgQUMFU6R/ZNlHvf
jbRg0dYO4eQ46kQwQwYDVR0jBDwwOoAUMFU6R/ZNlHvfjbRg0dYO4eQ46kShF6QV
MBMxETAPBgNVBAMTCENoYW5nZU1lggkA+T8a6jkAzoAwDAYDVR0TBAUwAwEB/zAL
BgNVHQ8EBAMCAQYwDQYJKoZIhvcNAQELBQADggEBADEkL11AUEX8WpiB0Zw5m1id
+QIKxnHCFml/9dDvjQyN+umXYt1alo36bqtKX+29gFSWhLdP5An//Fj1rxGEG90v
TFSTzZa4dj87Kw6PIZKF8Uad1aW5gr6QLK1nruoRksaJOaY/Z0YMLWtIdwTDcHo9
AkXK6ffCbWyb26piApixaMIdE4c7WvlTIm+b7WbcILS1YzuNxH/QVbFBJP4y0sJL
fBQmbtn6dp1aUmvAIig88t6wcMvkMmz9AiOdJ4xvEvRxvMzhTrjH2zO2qP6CRTwA
H/YIA4pisVgc8tGbdBLQ9qcEmB9knQVB3cWPjkqxWenDjRTD0vVKqiyZAlv4lqw=
-----END CERTIFICATE-----
</ca>
<key>
-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDNZ1+MvqEkjLcB
XwTp2K9J653Htb7gZPr1VjyeUs2HrW/7bRAnXJbS/9cv0aUHAMrVIyqEYT0H5P4M
kBy2ZMzKFafBwgX9deMWRvC0e8qUNv0UtGUhEiNVJA0wUQbo9attM60K1XAviSlF
sFMS41N2iEFQTOKKKtBGHH47Gf+ETORj/Db7KFiIhVGwMFE3s0CH0GVsW+XazTD1
Nxulou71sOGBp8v10uJ/QOfAZRq+pRtRmdlVgg5MxySktHYll2tY7uSIVYnE8d+h
vmUJYOrPc83i0H50iTBlvfOqVAPGH37XoaJ1RarsHg6RtT8Nlk1FZq0hiePOqNe7
erH/mhATAgMBAAECggEAdNXeFdLBGmcoGZGQ2+szGdr57oVEw6Ls1Oxuoqf63Lgc
wGkzDRCvgemg30RimG8s8LuGDbK54mmw0DiQ/Hatvi0/NQlGGvwZZayIckEP4+q7
XjGWbI9CpcVR8y/DvHMxRXZlcYoivAdLAKbhOhcwfHXYoPJ60Zi0y4ydiMSrAPcu
+y/b448kep+F/Z6hpLH+5ga/DiHbsR3xhr+JYjre1cM0pl1nPHIUKpqO7izdpZcy
lOu6V3ZuO9I4uwz4xb4W/pFC4geNRL+BzHCKx3h58zD2r43MWel95aW/vh08RSEx
5WkSaecKXsLr63/4FkOKF3YfmstSGigLZlriFsHZcQKBgQDlqYXsm/xAfqcKOlDp
2DIkN9Il+gB60QWImSG3I0Ns2jS9+jZ/L8koAfnWlSQbqQ1e+4LCRlXGmH4CSM+y
c6BCJLk1m/lJHP6H8hSaDKIjfsN4KHKwXy6UzoJH/KoovNTa29N/xX2K9huXerId
9UV5XiCH8LrFUkmZv2fqe1nezwKBgQDk9aqVq0hVAhuyPUufxapDKul8xA7nVHwx
8tdoQquJMKnYR6iVppAaoI6So/EMXNQZJ3kCaG3Z8vCjXBaDNMSuW1aDSw7Hv3kB
GnYkbVxVJ7ZL6vvWIkeBEzfXxHvXiA1gg9APPtTv+Tb0TkR3wkxZCkg5wkQsXIU4
sa9BTdyrfQKBgQCekCym8At5e/hYV2sGCP6VgvTUw4cRRL9NUGy2xOIIhZ9kixyV
M6jutm6IePA1KMLSkVP2ThlqxF47tYmw66P6BuDY4pd6o0oZEkqnEZHgb+UFUOfe
XdkLZIkOqqPQ/I75jEy6KuBC0Si7rTrM9ErDQPm04cAR/H5UaJKWkhO6gQKBgQDQ
YeLqq2R+sheBBpaQiLeowCKXgl1KH7OVRj7UznEOwLKkfLur0FexVFXOktUtekMz
zaAuF9t7FMf89jArJFipk8nOXv7Jv7Oi1HGYP8xcWHNq7yhbwQExMcuOXm6UQGhk
YjN33Kiy7DAe9CkOklEobNpFb1Dayy4Y5mbqWbIwhQKBgBL9CdH+Za01PzYCIcjS
zSeCioeLJRjxOSDHJzBPsoyEwFu7GKHgq70YZTygbOyNT4zMj1foPmvXHUaelClL
Mh74IzHP4t++pnObX1Kq/jYyCg4qFWIEWzzQLCrpQjPyCMnGT5I1TKl5EjJGiFam
iQK5dTnrBOL8H83f1Lot4z52
-----END PRIVATE KEY-----
</key>
<cert>
Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number: 2 (0x2)
    Signature Algorithm: sha256WithRSAEncryption
        Issuer: CN=ChangeMe
        Validity
            Not Before: Mar 30 07:15:56 2017 GMT
            Not After : Mar 28 07:15:56 2027 GMT
        Subject: CN=treeup
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                Public-Key: (2048 bit)
                Modulus:
                    00:cd:67:5f:8c:be:a1:24:8c:b7:01:5f:04:e9:d8:
                    af:49:eb:9d:c7:b5:be:e0:64:fa:f5:56:3c:9e:52:
                    cd:87:ad:6f:fb:6d:10:27:5c:96:d2:ff:d7:2f:d1:
                    a5:07:00:ca:d5:23:2a:84:61:3d:07:e4:fe:0c:90:
                    1c:b6:64:cc:ca:15:a7:c1:c2:05:fd:75:e3:16:46:
                    f0:b4:7b:ca:94:36:fd:14:b4:65:21:12:23:55:24:
                    0d:30:51:06:e8:f5:ab:6d:33:ad:0a:d5:70:2f:89:
                    29:45:b0:53:12:e3:53:76:88:41:50:4c:e2:8a:2a:
                    d0:46:1c:7e:3b:19:ff:84:4c:e4:63:fc:36:fb:28:
                    58:88:85:51:b0:30:51:37:b3:40:87:d0:65:6c:5b:
                    e5:da:cd:30:f5:37:1b:a5:a2:ee:f5:b0:e1:81:a7:
                    cb:f5:d2:e2:7f:40:e7:c0:65:1a:be:a5:1b:51:99:
                    d9:55:82:0e:4c:c7:24:a4:b4:76:25:97:6b:58:ee:
                    e4:88:55:89:c4:f1:df:a1:be:65:09:60:ea:cf:73:
                    cd:e2:d0:7e:74:89:30:65:bd:f3:aa:54:03:c6:1f:
                    7e:d7:a1:a2:75:45:aa:ec:1e:0e:91:b5:3f:0d:96:
                    4d:45:66:ad:21:89:e3:ce:a8:d7:bb:7a:b1:ff:9a:
                    10:13
                Exponent: 65537 (0x10001)
        X509v3 extensions:
            X509v3 Basic Constraints:
                CA:FALSE
            X509v3 Subject Key Identifier:
                D1:77:B7:A3:22:1C:A8:95:88:65:CD:E9:75:64:A2:67:B4:0D:15:EA
            X509v3 Authority Key Identifier:
                keyid:30:55:3A:47:F6:4D:94:7B:DF:8D:B4:60:D1:D6:0E:E1:E4:38:EA:44
                DirName:/CN=ChangeMe
                serial:F9:3F:1A:EA:39:00:CE:80

            X509v3 Extended Key Usage:
                TLS Web Client Authentication
            X509v3 Key Usage:
                Digital Signature
    Signature Algorithm: sha256WithRSAEncryption
         1d:6c:f0:d7:d4:20:f6:d3:51:55:b4:48:d3:14:69:33:73:63:
         ad:09:7f:6c:26:6d:67:04:66:63:4b:0b:9a:4c:1c:a7:9e:8e:
         e0:14:5e:62:26:b3:05:f9:8c:a0:f9:aa:e5:b1:c1:a0:b2:5d:
         07:9a:01:86:50:e5:cb:87:38:07:f9:49:2b:7f:98:e0:53:9e:
         7a:70:59:4e:32:ce:87:e0:a5:de:9d:2e:44:35:14:d2:4c:3e:
         44:4e:cd:3a:c8:be:6d:74:ae:a4:60:4c:71:9b:b0:e9:5f:e9:
         d8:9c:5a:9e:10:0a:e7:6d:24:ef:1e:a9:52:f0:c0:6b:12:35:
         04:a3:24:e2:a5:1f:59:93:d7:ff:15:40:22:72:95:de:35:c9:
         af:50:af:45:93:ce:0a:6f:db:84:3e:3b:af:0c:4c:d4:ff:4b:
         df:39:d2:15:16:8e:5e:ac:e3:c0:51:32:b5:63:f1:6f:83:de:
         97:f6:ec:09:9a:12:bd:1a:56:c4:51:2c:6b:c5:f6:9b:5f:ca:
         a6:d0:36:cd:5f:78:5e:92:72:51:bd:bc:bc:c2:ce:0d:a8:ac:
         13:3f:f8:c8:56:2a:f9:57:dc:4a:18:cd:87:08:1c:53:13:15:
         e6:4c:d2:24:97:00:b8:57:ca:ee:ca:60:23:51:5d:99:87:de:
         c6:45:d9:60
-----BEGIN CERTIFICATE-----
MIIDNDCCAhygAwIBAgIBAjANBgkqhkiG9w0BAQsFADATMREwDwYDVQQDEwhDaGFu
Z2VNZTAeFw0xNzAzMzAwNzE1NTZaFw0yNzAzMjgwNzE1NTZaMBExDzANBgNVBAMT
BnRyZWV1cDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAM1nX4y+oSSM
twFfBOnYr0nrnce1vuBk+vVWPJ5SzYetb/ttECdcltL/1y/RpQcAytUjKoRhPQfk
/gyQHLZkzMoVp8HCBf114xZG8LR7ypQ2/RS0ZSESI1UkDTBRBuj1q20zrQrVcC+J
KUWwUxLjU3aIQVBM4ooq0EYcfjsZ/4RM5GP8NvsoWIiFUbAwUTezQIfQZWxb5drN
MPU3G6Wi7vWw4YGny/XS4n9A58BlGr6lG1GZ2VWCDkzHJKS0diWXa1ju5IhVicTx
36G+ZQlg6s9zzeLQfnSJMGW986pUA8YfftehonVFquweDpG1Pw2WTUVmrSGJ486o
17t6sf+aEBMCAwEAAaOBlDCBkTAJBgNVHRMEAjAAMB0GA1UdDgQWBBTRd7ejIhyo
lYhlzel1ZKJntA0V6jBDBgNVHSMEPDA6gBQwVTpH9k2Ue9+NtGDR1g7h5DjqRKEX
pBUwEzERMA8GA1UEAxMIQ2hhbmdlTWWCCQD5PxrqOQDOgDATBgNVHSUEDDAKBggr
BgEFBQcDAjALBgNVHQ8EBAMCB4AwDQYJKoZIhvcNAQELBQADggEBAB1s8NfUIPbT
UVW0SNMUaTNzY60Jf2wmbWcEZmNLC5pMHKeejuAUXmImswX5jKD5quWxwaCyXQea
AYZQ5cuHOAf5SSt/mOBTnnpwWU4yzofgpd6dLkQ1FNJMPkROzTrIvm10rqRgTHGb
sOlf6dicWp4QCudtJO8eqVLwwGsSNQSjJOKlH1mT1/8VQCJyld41ya9Qr0WTzgpv
24Q+O68MTNT/S9850hUWjl6s48BRMrVj8W+D3pf27AmaEr0aVsRRLGvF9ptfyqbQ
Ns1feF6SclG9vLzCzg2orBM/+MhWKvlX3EoYzYcIHFMTFeZM0iSXALhXyu7KYCNR
XZmH3sZF2WA=
-----END CERTIFICATE-----
</cert>
<tls-auth>
#
# 2048 bit OpenVPN static key
#
-----BEGIN OpenVPN Static key V1-----
e94c539a0ea5f1f3c4edbc8c998fe76a
637ca7aa8ecf3401ec6d5609e22331bf
73b04de83598c510f631132db25fd6d6
3648665729c818e226ab77e01e7d0140
8252abfbd66ee2e8bc08e60f258f08bd
7f367e3e3b08059d3f8924538e7ee396
e69017697e86c7e7dacd7cd57133acb6
c3533b94075b69a52ebe0120319ed34a
e19073d4c690a4678bebfc3a3cec527c
2f7ca9acdfd43952856226b6dfca004f
80ac279a88131fc5c5e070f14dfda8b8
6fe490c68d70b22cc6c6821226959123
8f8394768bd3c039e826f55df08c893c
6038be66e0599e61456684602bb11f8a
9f8827bf4409421d9fd44ae80064fa03
592381d6333a49662ccf7518e4bcdbb8
-----END OpenVPN Static key V1-----
</tls-auth>
key-direction 1
nobind
remote-cert-tls server
cipher AES-128-CBC
auth SHA256
persist-tun
# persist-tun also enables pre resolving to avoid DNS resolve problem
preresolve
# Use system proxy setting
management-query-proxy
# Custom configuration options
# You are on your on own here :)
# These options found in the config file do not map to config settings:
setenv opt block-outside-dns 
resolv-retry 60